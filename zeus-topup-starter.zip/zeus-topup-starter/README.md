# ZEUS TOPUP — Starter Website

A responsive static storefront starter for ZEUS TOPUP.

## Deploy with GitHub + Vercel (Android)

1. Extract this ZIP on your phone.
2. In GitHub, create a new repository named `zeus-topup`.
3. Upload `index.html` and this `README.md` to the repository root.
4. In Vercel, choose **Add New → Project**, import `zeus-topup`.
5. Framework preset: **Other**. Build command: leave blank. Output directory: leave blank (or `.` if prompted).
6. Deploy. Vercel will provide a preview URL.

## Important limitations

This is a frontend demo only. It does NOT include real authentication, database storage, payment processing, player-ID verification, order management, or automatic top-up delivery. Do not accept customer payments until a secure backend, payment gateway, and authorized recharge provider have been integrated and tested.

Package prices and catalog are demo values. Edit the `catalog` object in `index.html` to update them. BGMI prices are intentionally left blank (₹—) until verified.
